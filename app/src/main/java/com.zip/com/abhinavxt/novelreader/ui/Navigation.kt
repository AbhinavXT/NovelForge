package com.abhinavxt.novelreader.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.abhinavxt.novelreader.AppConfig
import com.abhinavxt.novelreader.data.DownloadManager
import com.abhinavxt.novelreader.data.NovelRepository
import com.abhinavxt.novelreader.data.ThemePreferences
import com.abhinavxt.novelreader.ui.screens.*
import java.net.URLDecoder
import java.net.URLEncoder
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LibraryMusic
import com.abhinavxt.novelreader.data.BackupManager
import com.abhinavxt.novelreader.data.ChapterPrefetcher
import com.abhinavxt.novelreader.data.PronunciationManager
import com.abhinavxt.novelreader.data.ReadingStatsTracker
import com.abhinavxt.novelreader.data.TTSManager
import com.abhinavxt.novelreader.data.UpdateChecker
import com.abhinavxt.novelreader.data.source.SourceManager
import com.abhinavxt.novelreader.ui.viewmodel.AudioPlayerViewModel
import com.abhinavxt.novelreader.util.NetworkMonitor


sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Search : Screen("search", "Search", Icons.Default.Search)
    object Library : Screen("library", "Library", Icons.Default.MenuBook)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)

    object Detail : Screen(
        route = "detail/{novelId}/{novelUrl}",
        title = "Detail",
        icon = Icons.Default.MenuBook
    ) {
        fun createRoute(novelId: String, novelUrl: String): String {
            val encoded = URLEncoder.encode(novelUrl, "UTF-8")
            return "detail/$novelId/$encoded"
        }
    }

    object Reader : Screen(
        route = "reader/{novelId}/{chapterId}/{chapterUrl}/{novelUrl}",
        title = "Reader",
        icon = Icons.Default.MenuBook
    ) {
        fun createRoute(novelId: String, chapterId: String, chapterUrl: String, novelUrl: String): String {
            val encodedChapterUrl = URLEncoder.encode(chapterUrl, "UTF-8")
            val encodedNovelUrl = URLEncoder.encode(novelUrl, "UTF-8")
            return "reader/$novelId/$chapterId/$encodedChapterUrl/$encodedNovelUrl"
        }
    }

    object Downloads : Screen(
        route = "downloads",
        title = "Downloads",
        icon = Icons.Default.Download
    )

    object AudioLibrary : Screen(
        route = "audio_library",
        title = "Audio",
        icon = Icons.Default.LibraryMusic
    )

    object AudioChapters : Screen(
        route = "audio_chapters/{folderName}",
        title = "Audio Chapters",
        icon = Icons.Default.LibraryMusic
    ) {
        fun createRoute(folderName: String): String {
            val encoded = URLEncoder.encode(folderName, "UTF-8")
            return "audio_chapters/$encoded"
        }
    }

    object AudioPlayer : Screen(
        route = "audio_player/{folderName}/{filePath}",
        title = "Audio Player",
        icon = Icons.Default.LibraryMusic
    ) {
        fun createRoute(folderName: String, filePath: String): String {
            val encodedFolder = URLEncoder.encode(folderName, "UTF-8")
            val encodedPath = URLEncoder.encode(filePath, "UTF-8")
            return "audio_player/$encodedFolder/$encodedPath"
        }
    }

    object Pronunciation : Screen(
        route = "pronunciation",
        title = "Pronunciation",
        icon = Icons.Default.MenuBook
    )

    object ReadingStats : Screen(
        route = "reading_stats",
        title = "Reading Stats",
        icon = Icons.Default.MenuBook
    )

    object Changelog : Screen(
        route = "changelog",
        title = "Changelog",
        icon = Icons.Default.MenuBook
    )

    object ImportFromUrl : Screen(
        route = "import_from_url/{url}",
        title = "Add Novel",
        icon = Icons.Default.MenuBook
    ) {
        fun createRoute(url: String): String {
            // URL must be URL-encoded because the raw URL contains ':/' etc.
            // Route-arg encoding is standard for any user-supplied strings.
            val encoded = URLEncoder.encode(url, "UTF-8")
            return "import_from_url/$encoded"
        }
    }
}

private fun constructNovelUrl(novelId: String): String {
    return SourceManager.constructNovelUrl(novelId)
}

@Composable
fun NavigationHost(
    navController: NavHostController,
    repository: NovelRepository,
    downloadManager: DownloadManager,
    ttsManager: TTSManager,
    backupManager: BackupManager,
    themePreferences: ThemePreferences,
    pronunciationManager: PronunciationManager,
    readingStatsTracker: ReadingStatsTracker,
    chapterPrefetcher: ChapterPrefetcher,
    audioPlayerViewModel: AudioPlayerViewModel,
    updateChecker: UpdateChecker,
    networkMonitor: NetworkMonitor,
    modifier: Modifier = Modifier
) {
    val startRoute = if (AppConfig.ONLINE_SOURCES_ENABLED) Screen.Home.route else Screen.Library.route

    NavHost(
        navController = navController,
        startDestination = startRoute,
        modifier = modifier,
        // ── Default screen transitions ──────────────────────────
        // Slide in from right + fade in when navigating forward.
        // Slide out to right + fade out when navigating back.
        // 250ms feels snappy without being jarring.
        enterTransition = {
            slideInHorizontally(
                initialOffsetX = { fullWidth -> fullWidth / 4 },
                animationSpec = tween(250)
            ) + fadeIn(animationSpec = tween(250))
        },
        exitTransition = {
            slideOutHorizontally(
                targetOffsetX = { fullWidth -> -fullWidth / 4 },
                animationSpec = tween(250)
            ) + fadeOut(animationSpec = tween(150))
        },
        popEnterTransition = {
            slideInHorizontally(
                initialOffsetX = { fullWidth -> -fullWidth / 4 },
                animationSpec = tween(250)
            ) + fadeIn(animationSpec = tween(250))
        },
        popExitTransition = {
            slideOutHorizontally(
                targetOffsetX = { fullWidth -> fullWidth / 4 },
                animationSpec = tween(250)
            ) + fadeOut(animationSpec = tween(150))
        }
    ) {
        // ── Online source screens (Browse/Search/Home) ────────────
        // Only registered when online sources are enabled

        if (AppConfig.ONLINE_SOURCES_ENABLED) {
            composable(Screen.Home.route) {
                HomeScreen(
                    repository = repository,
                    readingStatsTracker = readingStatsTracker,
                    onBrowseClick = {
                        navController.navigate(Screen.Search.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNovelClick = { novelId ->
                        val url = constructNovelUrl(novelId)
                        navController.navigate(Screen.Detail.createRoute(novelId, url))
                    },
                    onContinueReading = { novelId, chapterId, chapterUrl, novelUrl ->
                        navController.navigate(
                            Screen.Reader.createRoute(
                                novelId = novelId,
                                chapterId = chapterId,
                                chapterUrl = chapterUrl,
                                novelUrl = novelUrl
                            )
                        )
                    },
                    networkMonitor = networkMonitor
                )
            }

            composable(Screen.Search.route) {
                SearchScreen(
                    repository = repository,
                    onNovelClick = { novelPreview ->
                        val url = constructNovelUrl(novelPreview.id)
                        navController.navigate(Screen.Detail.createRoute(novelPreview.id, url))
                    },
                    networkMonitor = networkMonitor
                )
            }

            composable(Screen.Downloads.route) {
                DownloadsScreen(
                    repository = repository,
                    downloadManager = downloadManager,
                    onBackClick = { navController.popBackStack() },
                    onNovelClick = { novelId ->
                        val url = constructNovelUrl(novelId)
                        navController.navigate(Screen.Detail.createRoute(novelId, url))
                    },
                    networkMonitor = networkMonitor
                )
            }
        }

        composable(Screen.Library.route) {
            LibraryScreen(
                repository = repository,
                onNovelClick = { novelId ->
                    val url = constructNovelUrl(novelId)
                    navController.navigate(Screen.Detail.createRoute(novelId, url))
                },
                networkMonitor = networkMonitor
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                backupManager = backupManager,
                themePreferences = themePreferences,
                onNavigateToPronunciation = {
                    navController.navigate(Screen.Pronunciation.route)
                },
                onNavigateToReadingStats = {
                    navController.navigate(Screen.ReadingStats.route)
                },
                onNavigateToChangelog = {
                    navController.navigate(Screen.Changelog.route)
                },
                updateChecker = updateChecker,
            )
        }

        composable(Screen.Pronunciation.route) {
            PronunciationScreen(
                pronunciationManager = pronunciationManager,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.ReadingStats.route) {
            ReadingStatsScreen(
                readingStatsTracker = readingStatsTracker,
                repository = repository,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Screen.Changelog.route) {
            ChangelogScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.Detail.route,
            arguments = listOf(
                navArgument("novelId") { type = NavType.StringType },
                navArgument("novelUrl") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val novelId = backStackEntry.arguments?.getString("novelId")!!
            val novelUrl = URLDecoder.decode(
                backStackEntry.arguments?.getString("novelUrl")!!,
                "UTF-8"
            )

            NovelDetailScreen(
                novelId = novelId,
                novelUrl = novelUrl,
                repository = repository,
                downloadManager = downloadManager,
                ttsManager = ttsManager,
                readingStatsTracker = readingStatsTracker,
                networkMonitor = networkMonitor,
                onBackClick = { navController.popBackStack() },
                onChapterClick = { chapterId, chapterUrl ->
                    navController.navigate(
                        Screen.Reader.createRoute(
                            novelId = novelId,
                            chapterId = chapterId,
                            chapterUrl = chapterUrl,
                            novelUrl = novelUrl
                        )
                    )
                }
            )
        }

        composable(
            route = Screen.Reader.route,
            arguments = listOf(
                navArgument("novelId") { type = NavType.StringType },
                navArgument("chapterId") { type = NavType.StringType },
                navArgument("chapterUrl") { type = NavType.StringType },
                navArgument("novelUrl") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val novelId = backStackEntry.arguments?.getString("novelId")!!
            val chapterId = backStackEntry.arguments?.getString("chapterId")!!
            val chapterUrl = URLDecoder.decode(
                backStackEntry.arguments?.getString("chapterUrl")!!,
                "UTF-8"
            )
            val novelUrl = URLDecoder.decode(
                backStackEntry.arguments?.getString("novelUrl")!!,
                "UTF-8"
            )

            ReaderScreen(
                novelId = novelId,
                chapterId = chapterId,
                chapterUrl = chapterUrl,
                novelUrl = novelUrl,
                repository = repository,
                ttsManager = ttsManager,
                themePreferences = themePreferences,
                statsTracker = readingStatsTracker,
                chapterPrefetcher = chapterPrefetcher,
                onBackClick = { navController.popBackStack() }
            )
        }

        // ── Audio screens ────────────────────────────────────────

        composable(Screen.AudioLibrary.route) {
            AudioLibraryScreen(
                viewModel = audioPlayerViewModel,
                onNovelClick = { folderName ->
                    navController.navigate(Screen.AudioChapters.createRoute(folderName))
                },
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.AudioChapters.route,
            arguments = listOf(
                navArgument("folderName") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val folderName = URLDecoder.decode(
                backStackEntry.arguments?.getString("folderName")!!,
                "UTF-8"
            )

            AudioChapterListScreen(
                viewModel = audioPlayerViewModel,
                novelFolderName = folderName,
                onChapterClick = { folder, filePath ->
                    navController.navigate(Screen.AudioPlayer.createRoute(folder, filePath))
                },
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.AudioPlayer.route,
            arguments = listOf(
                navArgument("folderName") { type = NavType.StringType },
                navArgument("filePath") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val folderName = URLDecoder.decode(
                backStackEntry.arguments?.getString("folderName")!!,
                "UTF-8"
            )
            val filePath = URLDecoder.decode(
                backStackEntry.arguments?.getString("filePath")!!,
                "UTF-8"
            )

            AudioPlayerScreen(
                viewModel = audioPlayerViewModel,
                novelFolderName = folderName,
                chapterFilePath = filePath,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.ImportFromUrl.route,
            arguments = listOf(
                navArgument("url") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val url = URLDecoder.decode(
                backStackEntry.arguments?.getString("url") ?: "",
                "UTF-8"
            )
            ImportFromUrlScreen(
                sharedUrl = url,
                repository = repository,
                networkMonitor = networkMonitor,
                onBackClick = { navController.popBackStack() },
                onOpenNovel = { novelId, novelUrl ->
                    // Replace the import screen with the detail screen so
                    // the user doesn't see ImportFromUrl again if they hit
                    // back from the reader.
                    navController.navigate(Screen.Detail.createRoute(novelId, novelUrl)) {
                        popUpTo(Screen.ImportFromUrl.route) { inclusive = true }
                    }
                }
            )
        }
    }
}